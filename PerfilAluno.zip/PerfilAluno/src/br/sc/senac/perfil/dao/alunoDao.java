package br.sc.senac.perfil.dao;

import br.sc.senac.perfil.model.Aluno;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

class AlunoDao extends Dao<Aluno> {

    @Override
    public boolean cadastrar(Aluno aluno) throws SQLException {
        PreparedStatement ps = null;

        String sql = "INSERT INTO aluno (nome, dt_nasc, curso, fase) VALUES (?, ?, ?, ?)";

        try {
            Connection conn = this.obterConexao();
            try {
                ps = conn.prepareStatement(sql);

                ps.setString(1, aluno.getNome());
                ps.setDate(2, new java.sql.Date(aluno.getdt_nasc().getTime()));
                ps.setString(3, aluno.getCurso());
                ps.setString(4, aluno.getFase());

                ps.executeUpdate();

            } finally {
                try {
                    if (ps != null) {
                        ps.close();
                    }
                    conn.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }

        return true;
    }

    @Override
    public boolean atualizar(Aluno pojo) throws SQLException {
        return false;
    }

    @Override
    public boolean excluir(Aluno pojo) throws SQLException {
        return false;
    }

    @Override
    public Integer getCodigo(Aluno pojo) throws SQLException {
        return null;
    }
}