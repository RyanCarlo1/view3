package br.sc.senac.perfil.dao;

import br.sc.senac.perfil.util.ConnectionFactory;

import java.sql.Connection;
import java.sql.SQLException;

    abstract class Dao<Entity> {

    protected Connection obterConexao() throws SQLException {
        return ConnectionFactory.getConexao();
    }

    public abstract boolean cadastrar(Entity entity) throws SQLException;

    public abstract boolean atualizar(Entity entity) throws SQLException;

    public abstract boolean excluir(Entity entity) throws SQLException;

    public abstract Integer getCodigo(Entity entity) throws SQLException;

    protected void fecharConexao(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}