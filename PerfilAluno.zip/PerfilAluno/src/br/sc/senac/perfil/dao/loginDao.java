package br.sc.senac.perfil.dao;

import br.sc.senac.perfil.view.LoginView;
import br.sc.senac.perfil.util.ConnectionFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

class LoginDao {

    public List<LoginView> buscarLogin() {
        List<LoginView> logins = new ArrayList<>();

        String sql = "SELECT log_nome, log_senha FROM login";

        try (Connection conn = ConnectionFactory.getConexao();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                LoginView loginView = new LoginView();
                loginView.setLogin(rs.getString("log_nome"));
                loginView.setSenha(rs.getString("log_senha"));
                logins.add(loginView);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return logins;
    }
}