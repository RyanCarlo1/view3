package br.sc.senac.perfil.view;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class LoginView extends JFrame {

    private String senha;

    private String login;
    private JPanel pnlPerfil;
    private JLabel lblnome;
    private JLabel lblcurso;
    private JLabel lblfase;
    private JLabel lblnascimento;

    private JTextField txtnome;
    private JTextField txtnascimento;
    private JTextField txtcurso;
    private JButton btnenviar;
    private JTextField txtfase;

    public LoginView() {
        initComponents();
        addListeners();
    }

    private void initComponents() {
        setTitle("Perfil de Usuário");
        setSize(300, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(pnlPerfil);
        setVisible(true);
    }

    private void addListeners() {
        btnenviar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txtnome.setText("");
                txtcurso.setText("");
                txtnascimento.setText("");
                txtfase.setText("");

                try {
                    String url = "jdbc:mysql://localhost:3306/seu_banco_de_dados";
                    String username = "root";
                    String password = "root99";

                    Connection connection = DriverManager.getConnection(url, username, password);
                    Statement statement = connection.createStatement();
                    ResultSet resultSet = statement.executeQuery("SELECT * FROM aluno");


                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(LoginView.this, "Erro ao acessar o banco de dados.", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new LoginView();
            }
        });

    }
}
